module ThereCanBeOnlyOne where

-- onlyElem :: (Eq a) => a -> [a] -> Bool

-- onlyOnce :: (a -> Bool) -> [a] -> Bool
