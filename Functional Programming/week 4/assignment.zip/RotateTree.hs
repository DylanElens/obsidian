module RotateTree where

import Tree

--rotateLeft :: Tree a -> Tree a
--rotateRight :: Tree a -> Tree a
--rotateToRoot :: (Ord a) => a -> Tree a -> Tree a

--leftRotatedNode :: ?
--rightRotatedNode :: ?
