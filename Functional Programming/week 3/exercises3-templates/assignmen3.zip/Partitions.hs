module Partitions where

-- partitions :: ??

{-
If xs has n elements, how many elements does the list (partitions xs) have?
-}
