This directory contains the input and answers for the 34 public test cases on DOMjudge for the pumping stations problem. 

The input for each test case is in the .in file and the answer in the .ans file. The .path files contain a route with which the result in the corresponding .ans file can be achieved. Note that there may be multiple equivalent routes. 

